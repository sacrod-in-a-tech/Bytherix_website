export type ProductCategory = "digital" | "software";

export interface ProductItem {
  id: string;
  name: string;
  shortName: string;
  description: string;
  category: ProductCategory;
  label: string;
  action: string;
  href: string;
  accent: "blue" | "red" | "green";
  tags: string[];
}

export const digitalProducts: ProductItem[] = [
  {
    id: "pem",
    name: "PEM",
    shortName: "PEM",
    description:
      "A focused digital product experience designed to simplify modern workflows and everyday operations.",
    category: "digital",
    label: "Digital Product",
    action: "Explore PEM",
    href: "#",
    accent: "blue",
    tags: ["Digital", "Workflow", "Product"],
  },
  {
    id: "student-management",
    name: "Student Management System",
    shortName: "SMS",
    description:
      "A structured digital system designed to simplify student management, academic workflows, and administration.",
    category: "digital",
    label: "Digital Product",
    action: "Explore System",
    href: "#",
    accent: "green",
    tags: ["Education", "Management", "System"],
  },
  {
    id: "clinic-registration",
    name: "Clinic Registration System",
    shortName: "CRS",
    description:
      "A streamlined registration experience designed to make modern clinic operations simpler and more organized.",
    category: "digital",
    label: "Digital Product",
    action: "Explore System",
    href: "#",
    accent: "red",
    tags: ["Healthcare", "Registration", "System"],
  },
];

export const softwareProducts: ProductItem[] = [
  {
    id: "one-for-all",
    name: "One For All",
    shortName: "OFA",
    description:
      "A connected management ecosystem that brings people, operations, workflows, and information into one platform.",
    category: "software",
    label: "Software",
    action: "Explore One For All",
    href: "/products/one-for-all",
    accent: "blue",
    tags: ["Management", "Platform", "Software"],
  },
];

export const allProducts = [...digitalProducts, ...softwareProducts];