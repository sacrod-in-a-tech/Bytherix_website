import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import type { ProductItem } from "../data/product.data";

interface ProductCardProps {
  product: ProductItem;
  index: number;
  featuredLayout?: boolean;
}

const accentStyles = {
  blue: {
    glow: "bg-[#00AEEF]/10",
    text: "text-[#00AEEF]",
    border: "hover:border-[#00AEEF]/30",
    icon: "bg-[#00AEEF]/10",
  },
  green: {
    glow: "bg-[#20C997]/10",
    text: "text-[#20C997]",
    border: "hover:border-[#20C997]/30",
    icon: "bg-[#20C997]/10",
  },
  red: {
    glow: "bg-[#FF3B30]/10",
    text: "text-[#FF3B30]",
    border: "hover:border-[#FF3B30]/30",
    icon: "bg-[#FF3B30]/10",
  },
};

export default function ProductCard({
  product,
  index,
  featuredLayout = false,
}: ProductCardProps) {
  const accent = accentStyles[product.accent];

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.45,
        delay: index * 0.07,
      }}
      whileHover={{ y: -5 }}
      className={`group relative overflow-hidden rounded-3xl border border-slate-200 bg-white transition-all duration-500 hover:shadow-xl hover:shadow-slate-200/50 dark:border-white/[0.08] dark:bg-white/[0.025] dark:hover:shadow-black/20 ${accent.border} ${
        featuredLayout ? "lg:min-h-[360px]" : "min-h-[390px]"
      }`}
    >
      <div
        className={`pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full blur-3xl opacity-50 transition-opacity duration-500 group-hover:opacity-100 ${accent.glow}`}
      />

      <div className="relative flex h-full flex-col p-6 sm:p-7">
        <div className="flex items-center justify-between">
          <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm font-medium text-slate-600 dark:border-white/[0.08] dark:bg-white/[0.03] dark:text-slate-400">
            {product.label}
          </span>

          <span className={`flex h-9 w-9 items-center justify-center rounded-full ${accent.icon}`}>
            <ArrowUpRight
              className={`h-4 w-4 ${accent.text} transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5`}
            />
          </span>
        </div>

        <div className="flex flex-1 flex-col">
          <div className="mt-10 flex items-center justify-center">
            <motion.div
              whileHover={{
                rotate: 4,
                scale: 1.04,
              }}
              transition={{
                type: "spring",
                stiffness: 250,
                damping: 18,
              }}
              className="relative flex h-28 w-28 items-center justify-center rounded-[28px] border border-slate-200 bg-slate-50 shadow-lg shadow-slate-200/50 dark:border-white/[0.08] dark:bg-[#09152b] dark:shadow-black/20"
            >
              <div
                className={`absolute inset-4 rounded-2xl blur-xl ${accent.glow}`}
              />

              <span className="relative text-2xl font-semibold tracking-[-0.04em] text-slate-900 dark:text-white">
                {product.shortName}
              </span>
            </motion.div>
          </div>

          <div className="mt-8">
            <h3 className="text-2xl font-semibold tracking-[-0.03em] text-slate-950 dark:text-white">
              {product.name}
            </h3>

            <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
              {product.description}
            </p>
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            {product.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-500 dark:border-white/[0.07] dark:text-slate-500"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        <Link
          to={product.href}
          className={`mt-7 inline-flex w-fit items-center gap-2 text-sm font-semibold transition-colors ${accent.text}`}
        >
          <span>{product.action}</span>
          <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </Link>
      </div>

      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100 dark:via-white/20" />
    </motion.article>
  );
}