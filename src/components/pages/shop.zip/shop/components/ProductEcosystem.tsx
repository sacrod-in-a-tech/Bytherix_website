import { motion } from "motion/react";

const nodes = [
  {
    label: "Digital Products",
    color: "#00AEEF",
    position: "left-[12%] top-[23%]",
  },
  {
    label: "Software",
    color: "#20C997",
    position: "right-[12%] top-[23%]",
  },
  {
    label: "Management",
    color: "#FF3B30",
    position: "left-[15%] bottom-[20%]",
  },
  {
    label: "Resources",
    color: "#3157D5",
    position: "right-[15%] bottom-[20%]",
  },
];

export default function ProductEcosystem() {
  return (
<section className="px-4 pb-10 pt-2 sm:px-6 sm:pb-12 sm:pt-3 lg:px-10 lg:pb-14 lg:pt-4 xl:px-[60px]">
      <div className="mx-auto max-w-7xl">
        <div className="text-center">
          <p className="text-sm font-semibold text-[#20C997]">
            Product Ecosystem
          </p>

          <h2 className="mt-2 text-3xl font-semibold tracking-[-0.035em] text-slate-950 sm:text-4xl lg:text-5xl dark:text-white">
            Everything connects.
          </h2>

          <p className="mx-auto mt-4 max-w-xl text-base leading-7 text-slate-600 dark:text-slate-400">
            A growing ecosystem of digital products and software experiences
            connected through one technology vision.
          </p>
        </div>

        <div className="relative mx-auto mt-8 hidden h-[440px] max-w-5xl overflow-hidden rounded-3xl border border-slate-200 bg-slate-50 dark:border-white/[0.07] dark:bg-white/[0.015] sm:block">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,174,239,0.07),transparent_35%)]" />

          <svg
            className="absolute inset-0 h-full w-full"
            viewBox="0 0 1000 440"
            preserveAspectRatio="none"
          >
            <line
              x1="500"
              y1="220"
              x2="140"
              y2="105"
              stroke="currentColor"
              className="text-slate-300 dark:text-white/[0.08]"
            />

            <line
              x1="500"
              y1="220"
              x2="860"
              y2="105"
              stroke="currentColor"
              className="text-slate-300 dark:text-white/[0.08]"
            />

            <line
              x1="500"
              y1="220"
              x2="160"
              y2="350"
              stroke="currentColor"
              className="text-slate-300 dark:text-white/[0.08]"
            />

            <line
              x1="500"
              y1="220"
              x2="840"
              y2="350"
              stroke="currentColor"
              className="text-slate-300 dark:text-white/[0.08]"
            />
          </svg>

          <div className="absolute left-1/2 top-1/2 flex h-44 w-44 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-slate-200 bg-white shadow-xl shadow-slate-200/50 dark:border-white/10 dark:bg-[#071126] dark:shadow-black/20">
            <div className="text-center">
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                BYTHERIX
              </p>

              <p className="mt-1 text-lg font-semibold text-slate-950 dark:text-white">
                Product Hub
              </p>
            </div>
          </div>

          {nodes.map((node, index) => (
            <motion.div
              key={node.label}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.5,
                delay: index * 0.1,
              }}
              whileHover={{ scale: 1.05 }}
              className={`absolute ${node.position}`}
            >
              <div className="flex items-center gap-3 rounded-full border border-slate-200 bg-white px-4 py-3 shadow-sm dark:border-white/10 dark:bg-[#071126]">
                <span
                  className="h-2.5 w-2.5 rounded-full"
                  style={{
                    backgroundColor: node.color,
                    boxShadow: `0 0 12px ${node.color}`,
                  }}
                />

                <span className="whitespace-nowrap text-sm font-medium text-slate-700 dark:text-slate-300">
                  {node.label}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-8 grid gap-3 sm:hidden">
          {nodes.map((node) => (
            <div
              key={node.label}
              className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 dark:border-white/[0.07] dark:bg-white/[0.025]"
            >
              <span
                className="h-2.5 w-2.5 rounded-full"
                style={{
                  backgroundColor: node.color,
                  boxShadow: `0 0 10px ${node.color}`,
                }}
              />

              <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                {node.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}